A simple Flow Player set up for Web Browsers that plays the file given in the URL parameter.
